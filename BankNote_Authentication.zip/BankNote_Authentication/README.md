# Bank Note Authentication

A Streamlit-based machine learning app that predicts the authenticity of banknotes using variance, skewness, curtosis, and entropy.